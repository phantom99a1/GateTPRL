﻿using NLog;

namespace LogStation
{
    public class LogStationFacade
    {

        public static void Initconfig(int p_Inteval)
        {
            Common.Initconfig(p_Inteval);//tính theo giây
        }

        public static void InitConfig(int p_Inteval, Logger log)
        {
            Common.InitConfig(p_Inteval, log);
        }

        public static void StartWritetoFileThread()
        {
            Thread _threadWriteToLogFile = new Thread(() => WritetoLogFileThread());
            _threadWriteToLogFile.Name = "WritetoFileThread";
            _threadWriteToLogFile.IsBackground = true;
            _threadWriteToLogFile.Start();
        }

        public static void RecordforRPS(string p_FuncName, string p_ModuleName = "")
        {
            TPShandle.InputData(p_FuncName, p_ModuleName);
        }

        public static void RecordforPT(string p_FuncName, long p_ProcessingTime, bool RecordforRPS, string p_ModuleName = "")
        {
            Common.log.Info($"{p_FuncName} process in {p_ProcessingTime / 10} us");
            PThandle.InputData(p_FuncName, p_ProcessingTime, p_ModuleName);
            if (RecordforRPS) { TPShandle.InputData(p_FuncName, p_ModuleName); }
        }

        private static void WritetoLogFileThread()
        {
            Common.log.Info($"START WritetoFileThread ManagedThreadId:{Thread.CurrentThread.ManagedThreadId.ToString()}");
            while (true)
            {
                try
                {
                    TPShandle.WritetoLog();
                    PThandle.WritetoLog();

                    Thread.Sleep(Common.SleepInteval);
                }
                catch
                {
                    Thread.Sleep(Common.SleepInteval);
                }

            }
        }

        public static void WritetoLog()
        {
            try
            {
                TPShandle.WritetoLog();
                PThandle.WritetoLog();

                Thread.Sleep(Common.SleepInteval);
            }
            catch
            {
                Thread.Sleep(Common.SleepInteval);
            }
        }
    }
}