﻿/*
 * Author :   – Navisoft.
 * Summary: Đây là class tiếp nhận thông tin và xử lý cho phần Processing Time
 * Modification Logs:
 * DATE             AUTHOR      DESCRIPTION
 * --------------------------------------------------------
 */


namespace LogStation
{
    internal class PThandle
    {
        private static Dictionary<string, PTinfo> c_PTstore = new Dictionary<string, PTinfo>();

        internal static bool InputData(string p_FuncName,long p_ProcessingTime ,string p_ModuleName = "")
        {
            if (c_PTstore.ContainsKey(p_FuncName) == false)
            {
                c_PTstore.Add(p_FuncName, new PTinfo()
                {
                    FunctionName = p_FuncName,
                    ModuleName = p_ModuleName,
                    Lasttime = DateTime.Now.Ticks,
                    PTMax = p_ProcessingTime,
                    PTSMin = p_ProcessingTime,
                    PTLast = p_ProcessingTime,
                    TotalProcessConsumes = p_ProcessingTime,
                    TotalProcessTimes = 1
                });
               
            }
            else
            {
                PTinfo _PTinfo = c_PTstore[p_FuncName];

                //cập nhạt thông tin
                _PTinfo.Lasttime = DateTime.Now.Ticks;
                _PTinfo.PTLast = p_ProcessingTime;


                //so sánh để cập nhật min, max
                if (_PTinfo.PTLast > _PTinfo.PTMax)
                {
                    _PTinfo.PTMax = _PTinfo.PTLast;
                }
                if (_PTinfo.PTLast < _PTinfo.PTSMin)
                {
                    _PTinfo.PTSMin = _PTinfo.PTLast;
                }
                _PTinfo.TotalProcessConsumes += p_ProcessingTime;
                _PTinfo.TotalProcessTimes++;
            }    



            return true;
        }

        internal static void WritetoLog()
        {
            foreach (PTinfo _PTinfo in c_PTstore.Values)
            {
                Common.log.Info(_PTinfo.ToString());
            }
        }
    }

    internal class PTinfo
    {
        public long Lasttime { get; set; }        
        public string FunctionName { get; set; }    //tên chức năng muốn thống kê
        public string ModuleName { get; set; }    //tên module
        public long PTMax { get; set; }    //giá trị max
        public long PTSMin { get; set; }   //giá trị min
        public long PTLast { get; set; }    //giá trị gần nhất
        public int TotalProcessTimes { get; set; } //tổng số lần xử lý
        public long TotalProcessConsumes { get;set; } //tổng thời gian xử lý
        public override string ToString()
        {
            return $"FunctionName:{@FunctionName}|ModuleName:{@ModuleName}| PTLast:{PTLast}| PTMax:{PTMax}| PTSMin:{PTSMin}|PTSAvg:{TotalProcessConsumes/TotalProcessTimes}";
        }
    }
}
