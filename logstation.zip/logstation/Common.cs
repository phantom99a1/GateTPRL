﻿namespace LogStation
{
    internal class Common
    {
        internal static NLog.Logger log = NLog.LogManager.GetCurrentClassLogger();
        internal static int Inteval = 30;//tính theo giây
        internal static int SleepInteval = Inteval * 1000;//30 giây nhưng thread sleep tính theo miligiay nên cần nhân 1000
        internal static long TickInteval = Inteval * TimeSpan.TicksPerSecond;

        public static void Initconfig(int p_Inteval)
        {
            Inteval = p_Inteval > 0 ? p_Inteval : 60; //tính theo giây
            TickInteval = Inteval * TimeSpan.TicksPerSecond;
            SleepInteval = Inteval * 1000;
        }

        public static void InitConfig(int p_Inteval, NLog.Logger logger)
        {
            Inteval = p_Inteval;//tính theo giây
            TickInteval = Inteval * TimeSpan.TicksPerSecond;
            SleepInteval = Inteval * 1000;
            log = logger;
        }
    }
}