﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using LogStation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogStation.Tests
{
    [TestClass()]
    public class LogStationFacadeTests
    {
        [TestMethod()]
        public void InitconfigTest()
        {
            LogStationFacade.Initconfig(30);
            //
            NLog.Logger log = NLog.LogManager.GetCurrentClassLogger();
            LogStationFacade.InitConfig(30, log);

            Assert.IsTrue(true);
        }

        [TestMethod()]
        public void StartWritetoFileThreadTest()
        {
            //Arrange
            LogStationFacade.RecordforPT("SendFinIn", TimeSpan.TicksPerMinute, true, "ProcessFinIn");
            LogStationFacade.RecordforPT("SendFinIn", TimeSpan.TicksPerMinute, true, "ProcessFinIn");
            LogStationFacade.RecordforPT("SendFinIn", TimeSpan.TicksPerMinute * 2, true, "ProcessFinIn");

            //Action
            LogStationFacade.StartWritetoFileThread();

            //Assert
            Assert.IsTrue(true);
        }

        [TestMethod()]
        public void RecordforRPSTest()
        {
            //Arrange 
            LogStationFacade.Initconfig(3);
            //
            NLog.Logger log = NLog.LogManager.GetCurrentClassLogger();
            LogStationFacade.InitConfig(3, log);

            string p_FuncName = "SendFinIn";
            string p_ModuleName = "ProcessFinIn";

            //Act
            LogStationFacade.RecordforRPS(p_FuncName, p_ModuleName);
            LogStationFacade.RecordforRPS(p_FuncName, p_ModuleName);
            LogStationFacade.RecordforRPS(p_FuncName, p_ModuleName);
            Thread.Sleep(3200);
            LogStationFacade.RecordforRPS(p_FuncName, p_ModuleName);



            //Assert
            Assert.IsTrue(true);
        }
    }
}