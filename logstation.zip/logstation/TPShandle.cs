﻿/*
 * Author :   – Navisoft.
 * Summary: Đây là class tiếp nhận thông tin và xử lý cho phần thống kê TPS
 * Modification Logs:
 * DATE             AUTHOR      DESCRIPTION
 * --------------------------------------------------------
 */

using System;

namespace LogStation
{
    internal class TPShandle
    {
        private static Dictionary<string, TPSinfo> c_TPSstore = new Dictionary<string, TPSinfo>();


        internal static bool InputData(string p_FuncName, string p_ModuleName = "")
        {
            if (c_TPSstore.ContainsKey(p_FuncName) == false)
            {
                c_TPSstore.Add(p_FuncName, new TPSinfo() { FunctionName = p_FuncName, ModuleName = p_ModuleName, Lasttime = DateTime.Now.Ticks, Number = 1, TPSMax=0, TPSMin= int.MaxValue });
            }
            else
            {
                TPSinfo _TPSinfo = c_TPSstore[p_FuncName];
                long _time = DateTime.Now.Ticks;
                if (_time - _TPSinfo.Lasttime >= Common.TickInteval)
                {
                    //đủ chu kỳ , thực hiện tính toán
                    _TPSinfo.TPSLast = (int)Math.Round((double)_TPSinfo.Number / Common.Inteval, 0);

                    //reset cho chu kỳ mới
                    _TPSinfo.Lasttime = _time;
                    _TPSinfo.Number = 1;

                    //so sánh để cập nhật min, max
                    if (_TPSinfo.TPSLast > _TPSinfo.TPSMax)
                    {
                        _TPSinfo.TPSMax = _TPSinfo.TPSLast;
                    }
                    if (_TPSinfo.TPSLast < _TPSinfo.TPSMin)
                    {
                        _TPSinfo.TPSMin = _TPSinfo.TPSLast;
                    }
                }
                else
                {
                    _TPSinfo.Number++;
                }

            }
            return true;
        }

        internal static void WritetoLog()
        {
            foreach (TPSinfo _TPSinfo in c_TPSstore.Values)
            {
                Common.log.Info(_TPSinfo.ToString());
            }
        }

    }

    internal class TPSinfo
    {
        public long Lasttime { get; set; }
        public int Number { get; set; }
        public string FunctionName { get; set; }    //tên chức năng muốn thống kê
        public string ModuleName { get; set; }    //tên module
        public int TPSMax { get; set; }    //giá trị max
        public int TPSMin { get; set; }    //giá trị min
        public int TPSLast { get; set; }    //giá trị gần nhất
        public override string ToString()
        {
            return $"FunctionName:{@FunctionName}| TPSLast:{TPSLast}| TPSMax:{@TPSMax}| TPSMin:{TPSMin} ";
        }
    }
}
